user_name = input("What is your name? ")

print("Hello " + user_name + " this is a game called Mad Libs! " + "\n" " The rules for Mad Libs are simple! " + "\n" " Rule number 1: When you are asked for a word please type in the corret type of word that matches the prefix. " + "\n" " That is all the rules you need to know, please enjoy your game!")

User_Verb = input("Choose a emotion: ")
User_adjective = input("Choose a texture: ")
User_Animal_Name = input("Choose a wacky name: ")
User_Adverb = input("Choose a time of day: ")
User_Favorite_Animal = input("Choose your favorite animal: ")
User_Article_Clothing = input("Choose article of clothing that you like: ")
User_Noun = input("Choose favorite resturant: ")
User_Place = input("Choose favorite place in the world: ")
User_Noun1 = input("Choose Political figure: ")
User_Noun2 = input("Choose Holiday animal: ")
User_Number = input("Choose number from 1-100: ")
 
print("Whenever i drive it makes me " + User_Verb + ". When i get home from driving my " + User_adjective + " " + User_Animal_Name + " comes up to me and loves on me. At " + User_Adverb + " i go and eat " + User_Favorite_Animal + " with my pet " + User_Animal_Name + " . After we go eating we like to shop for " + User_Article_Clothing + " and try many other diffrent " + User_Noun + ". Our favrite place to go after our day has ended is " + User_Place + " and just relax with our family friends, " + User_Noun1 + " " + User_Noun2 + ". Finally after the day has ended we lay our heads on " + User_Number + " iranian missles and have a good night sleep")